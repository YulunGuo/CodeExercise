from audioop import add
from cmath import log
from datetime import datetime
from hmac import trans_36
from statistics import mode
from unittest import case
import tensorflow as tf
import numpy as np

# 载入数据
minst = tf.keras.datasets.mnist
(train_x,train_y),(test_x,test_y) = minst.load_data()
# 归一化
X_train,X_test = tf.cast(train_x/255,tf.float32),tf.cast(test_x/255,tf.float32)
Y_train,Y_test = tf.cast(train_y,tf.int16),tf.cast(test_y,tf.int16)


# 构造网络LeNet-5
model = tf.keras.models.Sequential()
# 卷积层1：6个5x5卷积核
model.add(tf.keras.layers.Conv2D(filters=6,kernel_size=(5,5),padding='same',activation='relu',input_shape = (28,28,1)))
# 池化层2
model.add(tf.keras.layers.MaxPool2D(pool_size=(2,2),strides=2,padding='same'))
# 卷积层3：16个5x5卷积核
model.add(tf.keras.layers.Conv2D(filters=16,kernel_size=(5,5),padding='valid',activation='relu'))
# 池化层4
model.add(tf.keras.layers.MaxPool2D(pool_size=(2,2),strides=2,padding='same'))
# 打平层5
model.add(tf.keras.layers.Flatten())
# 全连接层6
model.add(tf.keras.layers.Dense(units=120, activation='relu'))
# 全连接层7
model.add(tf.keras.layers.Dense(units=84, activation='relu'))
# 全连接层8
model.add(tf.keras.layers.Dense(units=10, activation='softmax'))
# 网络整体
model.summary()

# 配置网络
model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics='sparse_categorical_accuracy')

# TensoeBoard可视化
log_dir = 'logs/fit/' + datetime.now().strftime("%Y%m%d-%H%M%S")
tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=log_dir,histogram_freq=1)

# 开始训练
model.fit(X_train,Y_train,batch_size=32,epochs=5,validation_split=0.2,callbacks=[tensorboard_callback])

# 保存模型
model.save(filepath='./model/save_model.h5')

# 评估模型
model.evaluate(X_test,Y_test,verbose=2)


