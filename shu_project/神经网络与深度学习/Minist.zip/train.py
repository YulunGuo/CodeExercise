from distutils.command.build import build
from ntpath import join
from statistics import mode
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np

# 超参数
layers = [1,2,3,4] # 神经网络层数
nodes = [32,64,128] # 隐藏层节点数

# 加载数据
mnist = tf.keras.datasets.mnist
(train_x,train_y),(test_x,test_y) = mnist.load_data()

# 数据预处理
X_train, X_test = tf.cast(train_x/255.0, tf.float32), tf.cast(test_x/255.0,tf.float32)
y_train, y_test = tf.cast(train_y, tf.int16), tf.cast(test_y, tf.int16)

# 建立模型
# # 两层模型784——128——10
# model.add(tf.keras.layers.Flatten(input_shape = (28,28)))
# model.add(tf.keras.layers.Dense(128,activation='relu'))
# model.add(tf.keras.layers.Dense(10,activation='softmax'))
# model.summary()

def build_model(layer,node):
    model = tf.keras.Sequential()
    model.add(tf.keras.layers.Flatten(input_shape = (28,28)))
    for i in range(0,layer):
        model.add(tf.keras.layers.Dense(node,activation='relu'))
    model.add(tf.keras.layers.Dense(10,activation='softmax'))
    model.summary()
    return model

for i in layers:
    for j in nodes:
        model = build_model(i,j)

        # 配置训练方法
        model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['sparse_categorical_accuracy'])

        # 训练模型
        model.fit(X_train,y_train,batch_size=64,epochs=5,validation_steps=0.2)

        # 评估模型
        model.evaluate(X_test,y_test,verbose=2)


        # 模型参数的保存
        save_path = './weight/mnist_weights_{}_{}.h5'.format(i,j)
        model.save_weights(save_path)

        # 保存整个模型
        save_model_path = './model/mnist_model_{}_{}.h5'.format(i,j)
        model.save(filepath=save_model_path)
