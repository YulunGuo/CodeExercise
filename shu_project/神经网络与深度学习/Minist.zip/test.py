import tensorflow as tf

# 超参数
layers = [1,2,3,4] # 神经网络层数
nodes = [32,64,128] # 隐藏层节点数

# 加载数据
mnist = tf.keras.datasets.mnist
(train_x,train_y),(test_x,test_y) = mnist.load_data()

# 数据预处理
X_train, X_test = tf.cast(train_x/255.0, tf.float32), tf.cast(test_x/255.0,tf.float32)
y_train, y_test = tf.cast(train_y, tf.int16), tf.cast(test_y, tf.int16)


# 评估16种模型
for i in layers:
    for j in nodes:
        path =  './model/mnist_model_{}_{}.h5'.format(i,j)
        model = tf.keras.models.load_model(path)
        print("--------------------------------")
        print('隐藏层数：{} , 隐藏层每层节点数：{}'.format(i,j))
        model.evaluate(X_test,y_test,verbose=2)