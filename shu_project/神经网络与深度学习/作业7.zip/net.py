from statistics import mode
import tensorflow as tf
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

np.random.seed(612)

# 读入数据
path = './winequality-white.csv'
whitewine_df = pd.read_csv(path,sep=';',header=0)

whitewine_df = whitewine_df.drop_duplicates()


whitewine = np.array(whitewine_df)

# 将数据切分成训练集以及测试集
train_x = whitewine[0:3169,0:11] # shape = (3961,11)
train_y = whitewine[0:3169:,11] # shape = (3961,)

test_x = whitewine[3169:,0:11]
test_y = whitewine[3169:,11]


# x0 = np.ones(len(train_x)).reshape(-1,1) # shape = (3961,1)
# train_X = tf.cast(tf.concat([x0,train_x],axis=1),dtype=tf.float32) # shape = (3961,12)
# train_Y = tf.one_hot(tf.constant(train_y,dtype=tf.int32),10)  # shape = (3961,10)

# 训练
model = tf.keras.Sequential()
model.add(tf.keras.layers.Flatten(input_shape = (11,)))
model.add(tf.keras.layers.Dense(4096,activation='relu'))
model.add(tf.keras.layers.Dense(10,activation='softmax'))
model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['sparse_categorical_accuracy'])
model.summary()
model.fit(train_x,train_y,validation_split=0.1,batch_size=32,epochs=10)

print('------------------------------------------------------------------')
# 预测
model.evaluate(test_x,test_y,verbose=2)

# 保存模型
save_model_path = './model/save_model.h5'
model.save(filepath=save_model_path)
